const http = require('http');
const { Server } = require('socket.io');

// ——— HTTP + Socket.IO setup ———
const server = http.createServer((req, res) => {
  res.statusCode = 200;
  res.setHeader('Content-Type', 'text/plain');
  res.end('Socket.IO server');
});

const io = new Server(server, {
  cors: { origin: '*', methods: ['GET', 'POST'] }
});

// ——— Controller/Client maps ———
const controllers         = new Map(); // socketId → { id, name, available, posY }
const clientControllerMap = new Map(); // clientSocketId → controllerSocketId
const controllerClientMap = new Map(); // controllerSocketId → clientSocketId

// ——— Connection & event handlers ———
io.on('connection', socket => {
  console.log('A new connection has been made, socket ID:', socket.id);

  // — Registration: clients & controllers —
  socket.on('register', data => {
    console.log('Registration data:', data);
    if (data.role === 'client') {
      socket.join('clients');
      socket.join(socket.id);
      console.log(`Client registered: socket ID ${socket.id}`);
      const available = Array.from(controllers.values()).filter(c => c.available);
      socket.emit('availableControllers', available);
    } else if (data.role === 'controller') {
      controllers.set(socket.id, { id: socket.id, name: data.name, available: true, posY: 0.5 });
      console.log(`Controller registered: ${data.name} with socket ID ${socket.id}`);
      const available = Array.from(controllers.values()).filter(c => c.available);
      io.to('clients').emit('availableControllers', available);
    }
  });

  // — Controller selection/deselection —
  socket.on('selectController', controllerId => {
    const ctrl = controllers.get(controllerId);
    if (ctrl && ctrl.available) {
      ctrl.available = false;
      controllers.set(controllerId, ctrl);
      clientControllerMap.set(socket.id, controllerId);
      controllerClientMap.set(controllerId, socket.id);
      console.log(`Controller ${ctrl.name} (${controllerId}) has been selected by client ${socket.id}`);
      const available = Array.from(controllers.values()).filter(c => c.available);
      io.to('clients').emit('availableControllers', available);
      socket.join(controllerId);
    }
  });

  socket.on('deselectController', controllerId => {
    const ctrl = controllers.get(controllerId);
    if (ctrl) {
      ctrl.available = true;
      controllers.set(controllerId, ctrl);
      clientControllerMap.delete(socket.id);
      controllerClientMap.delete(controllerId);
      console.log(`Client ${socket.id} has deselected controller ${controllerId}`);
      io.to(socket.id).emit('controllerDeselected', { controllerId });
      const available = Array.from(controllers.values()).filter(c => c.available);
      io.to('clients').emit('availableControllers', available);
    }
  });

  // — Forward messages from controller to client —
  socket.on('messageFromController', (message) => {
    const controllerId = socket.id;
    const clientId     = controllerClientMap.get(controllerId);
    if (!clientId) return;

    console.log(`→ controller ${controllerId} → client ${clientId}`, message);
    io.emit('controllerMessage', { payload: message });
  });

  // — Disconnect handler (controllers) —
  socket.on('disconnect', () => {
    console.log('Socket disconnected:', socket.id);

    const clientId = controllerClientMap.get(socket.id);
    if (clientId) {
      io.to(clientId).emit('controllerDisconnected', { controllerId: socket.id });
      const ctrl = controllers.get(socket.id);
      if (ctrl) ctrl.available = true;
      controllers.set(socket.id, ctrl);
      controllerClientMap.delete(socket.id);
      clientControllerMap.delete(clientId);
      io.to('clients').emit('availableControllers', Array.from(controllers.values()).filter(c => c.available));
    }

    const controllerId = clientControllerMap.get(socket.id);
    if (controllerId) {
      const ctrl = controllers.get(controllerId);
      if (ctrl) ctrl.available = true;
      controllers.set(controllerId, ctrl);
      clientControllerMap.delete(socket.id);
      controllerClientMap.delete(controllerId);
      io.to('clients').emit('availableControllers', Array.from(controllers.values()).filter(c => c.available));
    }

    if (controllers.has(socket.id)) {
      controllers.delete(socket.id);
      io.to('clients').emit('availableControllers', Array.from(controllers.values()).filter(c => c.available));
    }
  });
});

// — Start server —
const PORT = 3000;
server.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
});
